'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { AlertTriangle, Bell, ClipboardList, Flag, LayoutDashboard, Megaphone, Menu, MessageSquare, Package, Settings, ShoppingCart, Store, UserCog, Users, ArrowRight } from 'lucide-react'

const sections = [
  ['نظرة عامة', '/admin', LayoutDashboard], ['الشكاوى والبلاغات', '/admin/reports', Flag], ['المحادثات', '/admin/chats', MessageSquare], ['الإعلانات', '/admin/announcements', Megaphone], ['المستخدمون', '/admin/users', Users], ['التجار', '/admin/merchants', Store], ['المنتجات', '/admin/products', Package], ['الطلبات', '/admin/orders', ShoppingCart], ['الإشعارات', '/admin/notifications', Bell], ['المحتوى المسيء', '/admin/banned-content', AlertTriangle], ['المشرفون والصلاحيات', '/admin/staff', UserCog], ['سجل العمليات', '/admin/audit-log', ClipboardList], ['الإعدادات', '/admin/settings', Settings],
] as const

export default function AdminMenuPage() {
  const pathname = usePathname()
  return (
    <section dir="rtl" className="min-h-[calc(100vh-4rem)] bg-background">
      <header className="sticky top-0 z-10 flex items-center gap-4 border-b border-border bg-card/95 px-4 py-4 backdrop-blur sm:px-6">
        <Link href="/admin" aria-label="العودة إلى لوحة الإدارة" className="flex size-10 shrink-0 items-center justify-center rounded-xl border border-border transition hover:bg-accent"><ArrowRight aria-hidden="true" /></Link>
        <div className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-primary text-primary-foreground"><Menu aria-hidden="true" /></div>
        <div><p className="text-xs text-muted-foreground">سالِكس</p><h1 className="font-serif text-xl font-semibold sm:text-2xl">أقسام المنصة</h1></div>
      </header>
      <div className="mx-auto max-w-3xl px-4 py-6 sm:px-6 sm:py-8">
        <p className="mb-5 text-sm text-muted-foreground">اختر القسم الذي تريد إدارته</p>
        <nav aria-label="أقسام الإدارة" className="grid gap-2 sm:grid-cols-2">
          {sections.map(([label, href, Icon]) => {
            const active = href === '/admin' ? pathname === href : pathname.startsWith(href)
            return <Link key={href} href={href} className={`group flex min-h-14 items-center gap-3 rounded-2xl border px-4 py-3 text-right transition ${active ? 'border-primary bg-primary text-primary-foreground' : 'border-border bg-card hover:border-primary/40 hover:bg-accent'}`}><span className={`flex size-9 shrink-0 items-center justify-center rounded-xl ${active ? 'bg-primary-foreground/15' : 'bg-muted'}`}><Icon aria-hidden="true" /></span><span className="flex-1 text-sm font-medium">{label}</span><span aria-hidden="true" className={`text-lg transition-transform group-hover:-translate-x-1 ${active ? 'text-primary-foreground/70' : 'text-muted-foreground'}`}>‹</span></Link>
          })}
        </nav>
      </div>
    </section>
  )
}
