'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import type { ReactNode } from 'react'
import { AlertTriangle, Bell, ClipboardList, Flag, LayoutDashboard, Megaphone, Menu, MessageSquare, Package, Settings, ShoppingCart, Store, UserCog, Users, LogOut } from 'lucide-react'
import AdminGuard from '@/components/admin/AdminGuard'

const navItems = [
  ['نظرة عامة', '/admin', LayoutDashboard], ['الشكاوى والبلاغات', '/admin/reports', Flag], ['المحادثات', '/admin/chats', MessageSquare], ['الإعلانات', '/admin/announcements', Megaphone], ['المستخدمون', '/admin/users', Users], ['التجار', '/admin/merchants', Store], ['المنتجات', '/admin/products', Package], ['الطلبات', '/admin/orders', ShoppingCart], ['الإشعارات', '/admin/notifications', Bell], ['المحتوى المسيء', '/admin/banned-content', AlertTriangle], ['المشرفون والصلاحيات', '/admin/staff', UserCog], ['سجل العمليات', '/admin/audit-log', ClipboardList], ['الإعدادات', '/admin/settings', Settings],
] as const

export default function AdminLayout({ children }: { children: ReactNode }) {
  const pathname = usePathname()
  return <AdminGuard><div dir="rtl" className="min-h-screen bg-background text-foreground">
    <header className="sticky top-0 z-20 flex h-16 items-center justify-between border-b border-border bg-card/95 px-4 backdrop-blur md:px-8">
      <div className="flex items-center gap-3"><Link href="/admin/menu" aria-label="فتح قائمة الأقسام" className="flex size-10 items-center justify-center rounded-xl border border-border bg-card text-foreground transition hover:bg-accent lg:hidden"><Menu aria-hidden="true" strokeWidth={2.25} /></Link><span className="flex size-9 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground">س</span><span className="font-serif text-xl">سالِكس</span></div>
      <div className="flex items-center gap-3"><details className="relative"><summary className="flex cursor-pointer list-none items-center gap-2 rounded-full px-2 py-1 hover:bg-accent"><span className="flex size-8 items-center justify-center rounded-full bg-secondary text-sm font-bold">م</span><span className="hidden text-sm sm:block">مشرف النظام</span></summary><div dir="rtl" className="absolute left-0 top-11 min-w-44 rounded-2xl border border-border bg-card p-2 text-right shadow-lg"><button className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-right text-sm hover:bg-accent"><LogOut aria-hidden="true" className="shrink-0" /><span>تسجيل الخروج</span></button></div></details></div>
    </header>
    <div className="flex">
      <aside className="hidden w-72 shrink-0 border-r border-border bg-sidebar p-4 lg:block"><nav aria-label="القائمة الرئيسية" className="flex flex-col gap-1 text-right">{navItems.map(([label, href, Icon]) => { const active = href === '/admin' ? pathname === href : pathname.startsWith(href); return <Link key={href} href={href} className={`flex w-full items-center gap-3 rounded-full px-4 py-3 text-right text-sm transition ${active ? 'bg-primary text-primary-foreground' : 'text-sidebar-foreground hover:bg-sidebar-accent'}`}><Icon aria-hidden="true" className="shrink-0" /> <span className="truncate">{label}</span></Link> })}</nav></aside>
      <main className="min-w-0 flex-1 px-4 py-6 md:px-8 md:py-10"><div className="mx-auto max-w-6xl">{children}</div></main>
    </div>
  </div></AdminGuard>
}
