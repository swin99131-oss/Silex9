'use client'

import { useEffect, useState } from 'react'
import {
  AlertTriangle,
  Ban,
  Bell,
  Check,
  CheckCircle2,
  ChevronDown,
  CirclePause,
  FileText,
  Flag,
  LayoutDashboard,
  Menu,
  MessageSquare,
  Megaphone,
  MoreHorizontal,
  PauseCircle,
  Search,
  Settings,
  ShieldCheck,
  UserCog,
  Users,
  X,
  XCircle,
  Loader,
} from 'lucide-react'
import { createClient } from '@/lib/supabase/client'

const navItems = [
  { label: 'نظرة عامة', icon: LayoutDashboard },
  { label: 'الشكاوى والبلاغات', icon: Flag },
  { label: 'المحادثات', icon: MessageSquare },
  { label: 'الإعلانات', icon: Megaphone },
  { label: 'المستخدمون', icon: Users },
  { label: 'المحتوى المسيء', icon: AlertTriangle },
  { label: 'المشرفون والصلاحيات', icon: UserCog },
  { label: 'الإعدادات', icon: Settings },
]

function StatusPill({ children, tone = 'neutral' }: { children: React.ReactNode; tone?: string }) {
  const tones: Record<string, string> = {
    red: 'bg-[#f8e4df] text-[#a94f3d]',
    orange: 'bg-[#fbedd5] text-[#a36a20]',
    purple: 'bg-[#eee6f6] text-[#765395]',
    green: 'bg-[#e4f0e1] text-[#557b52]',
    neutral: 'bg-[#efede8] text-[#777168]',
  }
  return (
    <span className={`inline-flex rounded-full px-2.5 py-1 text-[11px] font-semibold ${tones[tone] || tones.neutral}`}>
      {children}
    </span>
  )
}

interface Report {
  id: string
  reason: string
  created_at: string
  status: string
  reporter_id: string
}

interface Campaign {
  id: string
  title: string
  status: string
  created_at: string
}

interface Profile {
  id: string
  display_name: string
  email?: string
  role: string
}

function SectionScreen({
  active,
  reports,
  campaigns,
  stats,
  onResolveReport,
  onApproveCampaign,
  onRejectCampaign,
  notify,
}: {
  active: string
  reports: Report[]
  campaigns: Campaign[]
  stats: { reports: number; campaigns: number; suspendedUsers: number; blockedContent: number }
  onResolveReport: (id: string) => void
  onApproveCampaign: (id: string) => void
  onRejectCampaign: (id: string) => void
  notify: (message: string) => void
}) {
  const copy: Record<string, { title: string; description: string }> = {
    'الشكاوى والبلاغات': { title: 'الشكاوى والبلاغات', description: 'راجع البلاغات القادمة من المستخدمين واتخذ الإجراء المناسب.' },
    'المحادثات': { title: 'المحادثات', description: 'راقب المحادثات التي تم الإبلاغ عنها وتابع الحالات المفتوحة.' },
    'الإعلانات': { title: 'الإعلانات', description: 'وافق على الحملات الإعلانية أو ارفضها قبل ظهورها للزوار.' },
    'المستخدمون': { title: 'المستخدمون', description: 'إدارة الحسابات، الإيقاف، الحظر، والصلاحيات.' },
    'المحتوى المسيء': { title: 'المحتوى المسيء', description: 'مراجعة المنشورات والتعليقات التي تم التبليغ عنها.' },
    'المشرفون والصلاحيات': { title: 'المشرفون والصلاحيات', description: 'إدارة أعضاء فريق الإدارة ومستويات الوصول.' },
    'الإعدادات': { title: 'الإعدادات', description: 'إعدادات المنصة والتنبيهات وبيانات التواصل مع المدير.' },
  }
  const section = copy[active] || copy['الشكاوى والبلاغات']
  const isReports = active === 'الشكاوى والبلاغات' || active === 'المحادثات' || active === 'المحتوى المسيء'
  const isCampaigns = active === 'الإعلانات'

  return (
    <div className="space-y-6">
      <div>
        <p className="mb-2 text-sm text-[#99938b]">شاشات الإدارة</p>
        <h1 className="font-serif text-3xl font-semibold tracking-tight md:text-4xl">{section.title}</h1>
        <p className="mt-2 text-sm text-[#7c776f]">{section.description}</p>
      </div>
      {isReports && (
        <div className="rounded-2xl border border-[#e6e1d8] bg-[#fbfaf7] p-4 md:p-6">
          <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div><h2 className="font-serif text-xl font-semibold">الحالات الواردة من Supabase</h2><p className="mt-1 text-xs text-[#99938b]">{reports.length} حالات ظاهرة</p></div>
            <button onClick={() => notify('يتم تحديث البيانات من Supabase')} className="rounded-xl border border-[#e6e1d8] px-4 py-2 text-xs font-semibold hover:bg-white">تحديث البيانات</button>
          </div>
          {reports.length === 0 ? <p className="py-12 text-center text-sm text-[#99938b]">لا توجد بيانات حقيقية تحتاج إلى مراجعة.</p> : <div className="space-y-3">{reports.map((report) => <div key={report.id} className="flex flex-col gap-3 rounded-xl border border-[#eeeae2] bg-white/60 p-4 sm:flex-row sm:items-center sm:justify-between"><div><div className="flex flex-wrap items-center gap-2"><b className="text-sm">{report.reason}</b><StatusPill tone="red">{report.status}</StatusPill></div><p className="mt-2 text-xs text-[#8c867d]">{new Date(report.created_at).toLocaleString('ar-SA')}</p></div><div className="flex gap-2"><button onClick={() => onResolveReport(report.id)} className="rounded-lg bg-[#2e332e] px-3 py-2 text-xs font-semibold text-white">معالجة</button><button onClick={() => notify('تم تسجيل رفض البلاغ')} className="rounded-lg border border-[#e3c8c1] px-3 py-2 text-xs font-semibold text-[#a94f3d]">رفض</button></div></div>)}</div>}
        </div>
      )}
      {isCampaigns && (
        <div className="grid gap-4 md:grid-cols-2">{campaigns.length === 0 ? <div className="col-span-full rounded-2xl border border-[#e6e1d8] bg-[#fbfaf7] py-16 text-center text-sm text-[#99938b]">لا توجد إعلانات حقيقية بانتظار الموافقة.</div> : campaigns.map((campaign) => <div key={campaign.id} className="rounded-2xl border border-[#e6e1d8] bg-[#fbfaf7] p-5"><div className="flex items-start justify-between gap-3"><div><h2 className="font-semibold">{campaign.title}</h2><p className="mt-2 text-xs text-[#8c867d]">{new Date(campaign.created_at).toLocaleString('ar-SA')}</p></div><StatusPill tone="purple">{campaign.status}</StatusPill></div><div className="mt-5 flex gap-2"><button onClick={() => onApproveCampaign(campaign.id)} className="flex-1 rounded-lg bg-[#2e332e] py-2 text-xs font-semibold text-white">موافقة</button><button onClick={() => onRejectCampaign(campaign.id)} className="flex-1 rounded-lg border border-[#e3c8c1] py-2 text-xs font-semibold text-[#a94f3d]">رفض</button></div></div>)}</div>
      )}
      {!isReports && !isCampaigns && <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">{[['إجمالي البلاغات', stats.reports], ['إعلانات معلقة', stats.campaigns], ['مستخدمون موقوفون', stats.suspendedUsers]].map(([label, value]) => <div key={label as string} className="rounded-2xl border border-[#e6e1d8] bg-[#fbfaf7] p-5"><p className="text-sm text-[#817b72]">{label}</p><p className="mt-4 font-serif text-3xl font-semibold">{value}</p><p className="mt-2 text-xs text-[#99938b]">بيانات مباشرة من Supabase</p></div>)}</div>}
    </div>
  )
}

export default function AdminDashboard() {
  const [open, setOpen] = useState(false)
  const [active, setActive] = useState('نظرة عامة')
  const [notice, setNotice] = useState('')
  const [loading, setLoading] = useState(true)
  const [stats, setStats] = useState({
    reports: 0,
    campaigns: 0,
    suspendedUsers: 0,
    blockedContent: 0,
  })
  const [reports, setReports] = useState<Report[]>([])
  const [campaigns, setCampaigns] = useState<Campaign[]>([])
  const [resolvedReports, setResolvedReports] = useState<string[]>([])
  const [approvedCampaigns, setApprovedCampaigns] = useState<string[]>([])

  useEffect(() => {
    const fetchData = async () => {
      const supabase = createClient()
      try {
        setLoading(true)

        // جلب الإحصائيات
        const [reportsData, campaignsData, profilesData] = await Promise.all([
          supabase.from('reports').select('*', { count: 'exact' }).eq('status', 'pending'),
          supabase.from('campaigns').select('*', { count: 'exact' }).eq('status', 'pending'),
          supabase.from('profiles').select('*', { count: 'exact' }).eq('role', 'suspended'),
        ])

        setStats({
          reports: reportsData.count || 0,
          campaigns: campaignsData.count || 0,
          suspendedUsers: profilesData.count || 0,
          blockedContent: 0,
        })

        // جلب البلاغات الأخيرة
        if (reportsData.data) {
          setReports(reportsData.data.slice(0, 4))
        }

        // جلب الإعلانات بانتظار الموافقة
        if (campaignsData.data) {
          setCampaigns(campaignsData.data.slice(0, 3))
        }
      } catch (error) {
        console.error('[v0] Error fetching data:', error)
        notify('حدث خطأ في تحميل البيانات')
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [])

  const notify = (message: string) => {
    setNotice(message)
    window.setTimeout(() => setNotice(''), 2600)
  }

  const handleResolveReport = async (reportId: string) => {
    const supabase = createClient()
    try {
      await supabase
        .from('reports')
        .update({ status: 'resolved' })
        .eq('id', reportId)

      setResolvedReports([...resolvedReports, reportId])
      notify('تمت معالجة البلاغ بنجاح')
    } catch (error) {
      console.error('[v0] Error resolving report:', error)
      notify('خطأ في معالجة البلاغ')
    }
  }

  const handleApproveCampaign = async (campaignId: string) => {
    const supabase = createClient()
    try {
      await supabase
        .from('campaigns')
        .update({ status: 'approved' })
        .eq('id', campaignId)

      setApprovedCampaigns([...approvedCampaigns, campaignId])
      notify('تمت الموافقة على الإعلان بنجاح')
    } catch (error) {
      console.error('[v0] Error approving campaign:', error)
      notify('خطأ في الموافقة على الإعلان')
    }
  }

  const handleRejectCampaign = async (campaignId: string) => {
    const supabase = createClient()
    try {
      await supabase
        .from('campaigns')
        .update({ status: 'rejected' })
        .eq('id', campaignId)

      notify('تم رفض الإعلان وإرسال السبب للمعلن')
    } catch (error) {
      console.error('[v0] Error rejecting campaign:', error)
      notify('خطأ في رفض الإعلان')
    }
  }

  if (loading) {
    return (
      <main dir="rtl" className="min-h-screen bg-[#f7f5f0] text-[#262522] flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <Loader size={32} className="animate-spin text-[#c99a58]" />
          <p className="text-sm text-[#8a847b]">جاري تحميل البيانات...</p>
        </div>
      </main>
    )
  }

  return (
    <main dir="rtl" className="min-h-screen bg-[#f7f5f0] text-[#262522]">
      {notice && (
        <div className="fixed left-5 top-5 z-50 flex items-center gap-2 rounded-xl bg-[#2e332e] px-4 py-3 text-sm text-white shadow-xl">
          <CheckCircle2 size={16} className="text-[#d9b77a]" />
          {notice}
        </div>
      )}
      <header className="flex h-20 items-center justify-between border-b border-[#e6e1d8] bg-[#fbfaf7] px-5 md:px-10">
        <div className="flex items-center gap-4">
          <button
            className="rounded-xl p-2 text-[#6d6a64] hover:bg-[#efebe3] md:hidden"
            aria-label="فتح القائمة"
            onClick={() => setOpen(!open)}
          >
            {open ? <X size={21} /> : <Menu size={21} />}
          </button>
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-[14px] bg-[#2e332e] text-lg text-[#f2c96d]">
              ن
            </div>
            <div>
              <p className="font-serif text-lg font-semibold leading-none">لوحتي</p>
              <p className="mt-1 text-[11px] text-[#87827a]">لوحة تحكم الإدارة</p>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <div className="hidden items-center gap-2 rounded-xl border border-[#e6e1d8] bg-white px-3 py-2 text-xs text-[#8a847b] lg:flex">
            <ShieldCheck size={15} className="text-[#63815f]" />
            وضع الأدمن مفعل
          </div>
          <button className="relative rounded-xl p-2.5 text-[#6d6a64] hover:bg-[#efebe3]" aria-label="الإشعارات">
            <Bell size={19} />
            <span className="absolute right-2 top-2 h-1.5 w-1.5 rounded-full bg-[#d66e55]" />
          </button>
          <div className="mx-1 hidden h-7 w-px bg-[#e6e1d8] sm:block" />
          <button className="flex items-center gap-2 rounded-xl p-1.5 pl-2 hover:bg-[#efebe3]">
            <span className="flex h-8 w-8 items-center justify-center rounded-full bg-[#d7b58a] text-xs font-semibold">
              م
            </span>
            <span className="hidden text-right sm:block">
              <b className="block text-xs font-semibold">مشرف النظام</b>
              <small className="text-[10px] text-[#8b867e]">صلاحية كاملة</small>
            </span>
            <ChevronDown size={15} className="text-[#9a958d]" />
          </button>
        </div>
      </header>

      <div className="flex">
        {open && <button aria-label="إغلاق القائمة" onClick={() => setOpen(false)} className="fixed inset-0 z-10 mt-20 bg-[#262522]/20 md:hidden" />}
        <aside
          className={`${open ? 'translate-x-0' : 'translate-x-full'} fixed inset-y-0 right-0 z-20 mt-20 w-72 border-l border-[#e6e1d8] bg-[#fbfaf7] p-5 transition-transform md:static md:mt-0 md:block md:w-72 md:translate-x-0`}
        >
          <p className="mb-4 px-3 text-[10px] font-semibold tracking-[0.18em] text-[#aaa49b]">
            إدارة المنصة
          </p>
          <nav className="space-y-1">
            {navItems.map(({ label, icon: Icon }) => (
              <button
                key={label}
                onClick={() => {
                  setActive(label)
                  setOpen(false)
                }}
                className={`flex w-full items-center justify-between rounded-xl px-3 py-3 text-sm transition ${
                  active === label
                    ? 'bg-[#2e332e] text-white shadow-sm'
                    : 'text-[#6f6b64] hover:bg-[#efebe3]'
                }`}
              >
                <span className="flex items-center gap-3">
                  <Icon size={17} strokeWidth={1.8} />
                  {label}
                </span>
              </button>
            ))}
          </nav>
          <div className="mt-10 rounded-2xl bg-[#eeeadf] p-4">
            <p className="font-serif text-base font-semibold">تنبيه أمني</p>
            <p className="mt-2 text-xs leading-6 text-[#777168]">
              لديك {stats.reports} بلاغاً يحتاج إلى مراجعة.
            </p>
            <button
              onClick={() => setActive('الشكاوى والبلاغات')}
              className="mt-3 text-xs font-semibold text-[#81704c]"
            >
              مراجعة الآن ←
            </button>
          </div>
        </aside>

        <section className="min-w-0 flex-1 px-4 py-6 sm:px-5 sm:py-8 md:px-10 lg:px-14">
          <div className="mx-auto max-w-7xl">
            {active !== 'نظرة عامة' ? (
              <SectionScreen active={active} reports={reports} campaigns={campaigns} stats={stats} onResolveReport={handleResolveReport} onApproveCampaign={handleApproveCampaign} onRejectCampaign={handleRejectCampaign} notify={notify} />
            ) : <>
            <div className="mb-8 flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
              <div>
                <p className="mb-2 text-sm text-[#99938b]">
                  {new Date().toLocaleDateString('ar-SA')}
                </p>
                <h1 className="font-serif text-3xl font-semibold tracking-tight md:text-4xl">
                  مركز إدارة المنصة
                </h1>
                <p className="mt-2 text-sm text-[#7c776f]">
                  تابع البلاغات والمحتوى والإعلانات من مكان واحد.
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => notify('تم إرسال تقرير الحالة إلى المدير')}
                  className="flex items-center gap-2 rounded-xl border border-[#e6e1d8] bg-[#fbfaf7] px-4 py-3 text-sm font-semibold text-[#6f6b64] hover:bg-white"
                >
                  <FileText size={16} />
                  تقرير الحالة
                </button>
                <button
                  onClick={() => notify('تم فتح نموذج إضافة مشرف')}
                  className="flex items-center gap-2 rounded-xl bg-[#c99a58] px-4 py-3 text-sm font-semibold text-white shadow-sm hover:bg-[#b88a4c]"
                >
                  <UserCog size={16} />
                  إضافة مشرف
                </button>
              </div>
            </div>

            <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
              {[
                [
                  'بلاغات جديدة',
                  stats.reports.toString(),
                  'تحتاج مراجعة',
                  'red',
                  Flag,
                ],
                [
                  'محتوى محظور',
                  stats.blockedContent.toString(),
                  'خلال هذا الأسبوع',
                  'orange',
                  Ban,
                ],
                [
                  'إعلانات بانتظار الموافقة',
                  stats.campaigns.toString(),
                  'منذ اليوم',
                  'purple',
                  Megaphone,
                ],
                [
                  'مستخدمون موقوفون',
                  stats.suspendedUsers.toString(),
                  'إجراء نشط',
                  'green',
                  PauseCircle,
                ],
              ].map(([title, value, caption, tone, Icon]) => (
                <div
                  key={title as string}
                  className="rounded-2xl border border-[#e6e1d8] bg-[#fbfaf7] p-5"
                >
                  <div className="mb-5 flex items-start justify-between">
                    <p className="text-sm text-[#817b72]">{title}</p>
                    <span
                      className={`rounded-lg p-2 ${
                        tone === 'red'
                          ? 'bg-[#f8e4df] text-[#a94f3d]'
                          : tone === 'orange'
                            ? 'bg-[#fbedd5] text-[#a36a20]'
                            : tone === 'purple'
                              ? 'bg-[#eee6f6] text-[#765395]'
                              : 'bg-[#e4f0e1] text-[#557b52]'
                      }`}
                    >
                      <Icon size={16} />
                    </span>
                  </div>
                  <p className="font-serif text-2xl font-semibold">{value}</p>
                  <p className="mt-2 text-xs text-[#a09a91]">{caption}</p>
                </div>
              ))}
            </div>

            <div className="mt-6 grid gap-6 xl:grid-cols-[1.45fr_1fr]">
              <div className="rounded-2xl border border-[#e6e1d8] bg-[#fbfaf7] p-5 md:p-6">
                <div className="mb-5 flex items-center justify-between">
                  <div>
                    <h2 className="font-serif text-xl font-semibold">آخر البلاغات</h2>
                    <p className="mt-1 text-xs text-[#99938b]">
                      بلاغات المجتمع التي تحتاج تدخلاً
                    </p>
                  </div>
                  <button
                    onClick={() => setActive('الشكاوى والبلاغات')}
                    className="text-xs font-semibold text-[#9b7644]"
                  >
                    عرض الكل
                  </button>
                </div>

                {reports.length === 0 ? (
                  <div className="py-8 text-center">
                    <p className="text-sm text-[#99938b]">لا توجد بلاغات جديدة</p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {reports.map((report) => (
                      <div
                        key={report.id}
                        className={`flex flex-col gap-3 rounded-xl border border-[#eeeae2] p-3.5 transition sm:flex-row sm:items-center sm:justify-between ${
                          resolvedReports.includes(report.id)
                            ? 'opacity-50 bg-gray-100'
                            : 'bg-white/40'
                        }`}
                      >
                        <div className="flex items-start gap-3">
                          <div className="mt-0.5 rounded-lg bg-[#f8e4df] p-2 text-[#a94f3d]">
                            <Flag size={15} />
                          </div>
                          <div>
                            <div className="flex flex-wrap items-center gap-2">
                              <b className="text-xs">{report.reason}</b>
                              <StatusPill
                                tone={
                                  resolvedReports.includes(report.id)
                                    ? 'green'
                                    : 'red'
                                }
                              >
                                {resolvedReports.includes(report.id)
                                  ? 'تمت المعالجة'
                                  : 'جديد'}
                              </StatusPill>
                            </div>
                            <p className="mt-1 text-[11px] text-[#8c867d]">
                              {new Date(report.created_at).toLocaleDateString(
                                'ar-SA'
                              )}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center justify-between gap-3 sm:justify-start">
                          <span className="text-[10px] text-[#aaa49b]">
                            {new Date(report.created_at).toLocaleTimeString('ar-SA')}
                          </span>
                          <div className="flex gap-1">
                            <button
                              onClick={() => handleResolveReport(report.id)}
                              className="rounded-lg p-2 text-[#63815f] hover:bg-[#e4f0e1]"
                              aria-label="قبول البلاغ"
                              disabled={resolvedReports.includes(report.id)}
                            >
                              <Check size={15} />
                            </button>
                            <button
                              onClick={() => notify('تم رفض البلاغ')}
                              className="rounded-lg p-2 text-[#a94f3d] hover:bg-[#f8e4df]"
                              aria-label="رفض البلاغ"
                            >
                              <X size={15} />
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="rounded-2xl border border-[#e6e1d8] bg-[#fbfaf7] p-5 md:p-6">
                <div className="mb-5 flex items-center justify-between">
                  <div>
                    <h2 className="font-serif text-xl font-semibold">
                      إعلانات بانتظار القرار
                    </h2>
                    <p className="mt-1 text-xs text-[#99938b]">
                      راجع الإعلانات قبل نشرها
                    </p>
                  </div>
                  <Megaphone size={19} className="text-[#b7884a]" />
                </div>

                {campaigns.length === 0 ? (
                  <div className="py-8 text-center">
                    <p className="text-sm text-[#99938b]">لا توجد إعلانات بانتظار</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {campaigns.map((campaign) => (
                      <div key={campaign.id} className="rounded-xl bg-[#f5f1e9] p-3.5">
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <p className="text-xs font-semibold">{campaign.title}</p>
                            <p className="mt-1 text-[10px] text-[#918b82]">
                              {new Date(campaign.created_at).toLocaleDateString(
                                'ar-SA'
                              )}
                            </p>
                          </div>
                          <StatusPill
                            tone={
                              approvedCampaigns.includes(campaign.id)
                                ? 'green'
                                : 'purple'
                            }
                          >
                            {approvedCampaigns.includes(campaign.id)
                              ? 'مقبول'
                              : 'بانتظار'}
                          </StatusPill>
                        </div>
                        <div className="mt-3 flex gap-2">
                          <button
                            onClick={() => handleApproveCampaign(campaign.id)}
                            disabled={approvedCampaigns.includes(campaign.id)}
                            className="flex-1 rounded-lg bg-[#2e332e] py-2 text-[11px] font-semibold text-white hover:bg-[#424941] disabled:opacity-50"
                          >
                            <Check size={13} className="ml-1 inline" />
                            موافقة
                          </button>
                          <button
                            onClick={() => handleRejectCampaign(campaign.id)}
                            className="flex-1 rounded-lg border border-[#e3c8c1] py-2 text-[11px] font-semibold text-[#a94f3d] hover:bg-[#f8e4df]"
                          >
                            <X size={13} className="ml-1 inline" />
                            رفض
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
            </>}
          </div>
        </section>
      </div>
    </main>
  )
}
